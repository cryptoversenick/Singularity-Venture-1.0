// Slow-motion galaxy animation
const canvas = document.getElementById('galaxy-canvas');
const ctx = canvas.getContext('2d');

let stars = [];
let shootingStars = [];

function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}

class SlowStar {
    constructor() {
        this.reset();
    }

    reset() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.z = Math.random() * canvas.width; // Depth
        this.size = Math.random() * 1.5 + 0.5;
        this.opacity = Math.random() * 0.5 + 0.3;
        this.twinkleSpeed = (Math.random() - 0.5) * 0.003; // Very slow twinkle

        // Different star colors
        const rand = Math.random();
        if (rand > 0.9) {
            this.color = { r: 150, g: 200, b: 255 }; // Blue
        } else if (rand > 0.7) {
            this.color = { r: 255, g: 240, b: 200 }; // Yellow
        } else {
            this.color = { r: 255, g: 255, b: 255 }; // White
        }
    }

    update() {
        // Move through space (towards viewer) - quicker but smooth
        this.z -= 1.2;

        // Calculate position based on depth
        const k = 128.0 / this.z;
        const px = this.x * k + canvas.width / 2;
        const py = this.y * k + canvas.height / 2;

        this.screenX = px;
        this.screenY = py;
        this.screenSize = this.size * k;

        // Twinkle
        this.opacity += this.twinkleSpeed;
        if (this.opacity <= 0.3 || this.opacity >= 0.8) {
            this.twinkleSpeed *= -1;
        }

        // Reset when star passes viewer
        if (this.z < 1 || this.screenX < -50 || this.screenX > canvas.width + 50 ||
            this.screenY < -50 || this.screenY > canvas.height + 50) {
            this.x = (Math.random() - 0.5) * canvas.width;
            this.y = (Math.random() - 0.5) * canvas.height;
            this.z = canvas.width;
        }
    }

    draw() {
        if (this.screenX && this.screenY && this.screenSize > 0) {
            // Draw glow
            const gradient = ctx.createRadialGradient(
                this.screenX, this.screenY, 0,
                this.screenX, this.screenY, this.screenSize * 2
            );
            gradient.addColorStop(0, `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, ${this.opacity})`);
            gradient.addColorStop(1, `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, 0)`);

            ctx.fillStyle = gradient;
            ctx.beginPath();
            ctx.arc(this.screenX, this.screenY, this.screenSize * 2, 0, Math.PI * 2);
            ctx.fill();

            // Draw core
            ctx.fillStyle = `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, ${this.opacity})`;
            ctx.beginPath();
            ctx.arc(this.screenX, this.screenY, this.screenSize, 0, Math.PI * 2);
            ctx.fill();
        }
    }
}

class SlowShootingStar {
    constructor() {
        this.reset();
    }

    reset() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height * 0.5;
        this.length = Math.random() * 100 + 80;
        this.speed = Math.random() * 3 + 2;
        this.size = Math.random() * 1.5 + 0.8;
        this.opacity = 0;
        this.fadeIn = true;

        // Light blue shooting stars
        const colors = [
            { r: 135, g: 206, b: 250 },    // Light Sky Blue
            { r: 173, g: 216, b: 230 },    // Light Blue
            { r: 176, g: 224, b: 230 },    // Powder Blue
            { r: 100, g: 180, b: 255 },    // Light Blue
            { r: 0, g: 191, b: 255 },      // Deep Sky Blue
            { r: 135, g: 206, b: 235 },    // Sky Blue
            { r: 176, g: 196, b: 222 },    // Light Steel Blue
            { r: 240, g: 248, b: 255 }     // Alice Blue
        ];
        this.color = colors[Math.floor(Math.random() * colors.length)];
    }

    update() {
        // Fade in slowly
        if (this.fadeIn) {
            this.opacity += 0.005;
            if (this.opacity >= 0.8) {
                this.fadeIn = false;
            }
        } else {
            this.opacity -= 0.002;
        }

        this.x += this.speed;
        this.y += this.speed * 0.5;

        // Reset when off screen or fully faded
        if (this.opacity <= 0 || this.x > canvas.width + this.length || this.y > canvas.height) {
            // Random delay before next shooting star
            setTimeout(() => this.reset(), Math.random() * 10000 + 5000);
            this.opacity = 0;
            this.x = -1000; // Move off screen
        }
    }

    draw() {
        if (this.opacity > 0) {
            const gradient = ctx.createLinearGradient(
                this.x, this.y,
                this.x - this.length, this.y - this.length * 0.5
            );
            gradient.addColorStop(0, `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, ${this.opacity})`);
            gradient.addColorStop(1, `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, 0)`);

            ctx.strokeStyle = gradient;
            ctx.lineWidth = this.size;
            ctx.beginPath();
            ctx.moveTo(this.x, this.y);
            ctx.lineTo(this.x - this.length, this.y - this.length * 0.5);
            ctx.stroke();
        }
    }
}

function initStars() {
    stars = [];
    // Create 200 stars for parallax effect
    for (let i = 0; i < 200; i++) {
        stars.push(new SlowStar());
    }

    shootingStars = [];
    // Create 8 shooting stars
    for (let i = 0; i < 8; i++) {
        shootingStars.push(new SlowShootingStar());
    }
}

function animate() {
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Update and draw stars
    stars.forEach(star => {
        star.update();
        star.draw();
    });

    // Update and draw shooting stars
    shootingStars.forEach(star => {
        star.update();
        star.draw();
    });

    requestAnimationFrame(animate);
}

// Initialize
resizeCanvas();
initStars();
animate();

window.addEventListener('resize', () => {
    resizeCanvas();
    initStars();
});

// Smooth Scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Form Handling
const form = document.querySelector('.contact-form');
form.addEventListener('submit', (e) => {
    e.preventDefault();

    const formData = new FormData(form);

    // Show success message
    const button = form.querySelector('.submit-button');
    const originalText = button.textContent;
    button.textContent = 'Message Sent!';
    button.style.background = 'linear-gradient(135deg, #10b981, #059669)';

    setTimeout(() => {
        button.textContent = originalText;
        button.style.background = 'linear-gradient(135deg, var(--primary), var(--accent))';
        form.reset();
    }, 3000);
});

// Parallax Effect on Mouse Move - Disabled to keep text fixed
// document.addEventListener('mousemove', (e) => {
//     const mouseX = e.clientX / window.innerWidth;
//     const mouseY = e.clientY / window.innerHeight;

//     const cards = document.querySelectorAll('.card');
//     cards.forEach((card, index) => {
//         const speedX = (index + 1) * 5;
//         const speedY = (index + 1) * 5;
//         const x = (mouseX - 0.5) * speedX;
//         const y = (mouseY - 0.5) * speedY;
//         card.style.transform = `translateX(${x}px) translateY(${y}px)`;
//     });
// });

// Intersection Observer for Animations - Disabled to keep text fixed
// const observerOptions = {
//     threshold: 0.1,
//     rootMargin: '0px 0px -100px 0px'
// };

// const observer = new IntersectionObserver((entries) => {
//     entries.forEach(entry => {
//         if (entry.isIntersecting) {
//             entry.target.style.opacity = '1';
//             entry.target.style.transform = 'translateY(0)';
//         }
//     });
// }, observerOptions);

// document.querySelectorAll('section').forEach(section => {
//     section.style.opacity = '0';
//     section.style.transform = 'translateY(50px)';
//     section.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
//     observer.observe(section);
// });

// Scroll effect - fade out galaxy background as you scroll down
window.addEventListener('scroll', () => {
    const scrolled = window.scrollY;
    const windowHeight = window.innerHeight;
    const galaxyCanvas = document.getElementById('galaxy-canvas');
    const researchSection = document.querySelector('.research');

    // Calculate opacity based on scroll (fades out after first viewport)
    const fadeStart = windowHeight * 0.5;
    const fadeEnd = windowHeight * 2;

    let opacity = 1;
    if (scrolled > fadeStart) {
        opacity = 1 - Math.min((scrolled - fadeStart) / (fadeEnd - fadeStart), 0.7);
    }

    galaxyCanvas.style.opacity = opacity;

    // Dim the research section background when scrolling
    if (researchSection) {
        const researchTop = researchSection.offsetTop;
        const researchHeight = researchSection.offsetHeight;

        // Check if research section is in view
        if (scrolled + windowHeight * 0.5 >= researchTop && scrolled <= researchTop + researchHeight) {
            // Calculate how far into the section we've scrolled
            const sectionProgress = Math.min((scrolled + windowHeight * 0.5 - researchTop) / (windowHeight * 0.3), 1);
            const darkness = 0.08 + (sectionProgress * 0.12); // Darken from 0.08 to 0.2 (lighter)
            researchSection.style.background = `rgba(0, 0, 0, ${darkness})`;
        } else if (scrolled > researchTop + researchHeight) {
            // Keep it slightly dark after scrolling past
            researchSection.style.background = 'rgba(0, 0, 0, 0.2)';
        } else {
            // Reset before reaching section
            researchSection.style.background = 'rgba(99, 102, 241, 0.03)';
        }
    }
});

// Portfolio Returns Chart
const chartCanvas = document.getElementById('returns-canvas');
if (chartCanvas) {
    const chartCtx = chartCanvas.getContext('2d');

    // Set canvas size
    function resizeChart() {
        chartCanvas.width = chartCanvas.offsetWidth;
        chartCanvas.height = 400;
        drawChart();
    }

    // Timeline: Jan 2024 to Jan 2026 (25 months)
    const months = ['Jan 24', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan 25', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan 26'];

    // Singularity Portfolio: ~96% cumulative return (48% annual avg over 2 years)
    const portfolioData = [0, 5, 12, 18, 28, 35, 42, 48, 40, 55, 65, 75, 82, 72, 78, 85, 88, 92, 94, 95, 95.5, 96, 96, 96, 96];

    // S&P 500: ~25% cumulative return over 2 years (avg ~12% annual)
    const sp500Data = [0, 1, 2, 3, 5, 6, 7, 9, 6, 8, 10, 12, 14, 11, 13, 15, 17, 19, 21, 22, 23, 24, 24.5, 25, 25];

    function drawChart() {
        const width = chartCanvas.width;
        const height = chartCanvas.height;
        const paddingLeft = 60;
        const paddingRight = 100; // More space for labels
        const paddingTop = 60;
        const paddingBottom = 60;
        const chartWidth = width - paddingLeft - paddingRight;
        const chartHeight = height - paddingTop - paddingBottom;

        // Clear canvas
        chartCtx.clearRect(0, 0, width, height);

        // Draw grid
        chartCtx.strokeStyle = 'rgba(0, 212, 255, 0.1)';
        chartCtx.lineWidth = 1;

        // Horizontal grid lines - 8 lines for better granularity
        for (let i = 0; i <= 8; i++) {
            const y = paddingTop + (chartHeight / 8) * i;
            chartCtx.beginPath();
            chartCtx.moveTo(paddingLeft, y);
            chartCtx.lineTo(width - paddingRight, y);
            chartCtx.stroke();
        }

        // Vertical grid lines
        const numMonths = months.length - 1;
        for (let i = 0; i <= numMonths; i++) {
            const x = paddingLeft + (chartWidth / numMonths) * i;
            chartCtx.beginPath();
            chartCtx.moveTo(x, paddingTop);
            chartCtx.lineTo(x, height - paddingBottom);
            chartCtx.stroke();
        }

        // Linear scale function
        function getLinearY(value) {
            // Linear scale from 0% to max (120%)
            const minValue = 0;
            const maxValue = 120;
            const normalizedValue = (value - minValue) / (maxValue - minValue);
            const y = height - paddingBottom - normalizedValue * chartHeight;
            return y;
        }

        // Draw lines with null handling (starts from inception) and inception marker
        function drawLine(data, color, lineWidth, shadow) {
            chartCtx.strokeStyle = color;
            chartCtx.lineWidth = lineWidth;
            chartCtx.shadowColor = shadow;
            chartCtx.shadowBlur = 15;

            chartCtx.beginPath();
            let started = false;
            let inceptionX = null;
            let inceptionY = null;

            data.forEach((value, index) => {
                if (value === null) return;

                const x = paddingLeft + (chartWidth / (data.length - 1)) * index;
                const y = getLinearY(value);

                if (!started) {
                    chartCtx.moveTo(x, y);
                    started = true;
                    inceptionX = x;
                    inceptionY = y;
                } else {
                    chartCtx.lineTo(x, y);
                }
            });
            chartCtx.stroke();
            chartCtx.shadowBlur = 0;

            // Draw inception point marker (circle)
            if (inceptionX !== null && inceptionY !== null) {
                // Outer glow
                chartCtx.beginPath();
                chartCtx.arc(inceptionX, inceptionY, 8, 0, Math.PI * 2);
                chartCtx.fillStyle = shadow;
                chartCtx.fill();

                // Inner circle
                chartCtx.beginPath();
                chartCtx.arc(inceptionX, inceptionY, 5, 0, Math.PI * 2);
                chartCtx.fillStyle = color;
                chartCtx.fill();

                // White center dot
                chartCtx.beginPath();
                chartCtx.arc(inceptionX, inceptionY, 2, 0, Math.PI * 2);
                chartCtx.fillStyle = 'rgba(255, 255, 255, 0.9)';
                chartCtx.fill();
            }
        }

        // Draw S&P 500 (gray/white - dashed line)
        chartCtx.strokeStyle = 'rgba(156, 163, 175, 0.8)';
        chartCtx.lineWidth = 2;
        chartCtx.setLineDash([8, 4]);
        chartCtx.shadowColor = 'rgba(156, 163, 175, 0.4)';
        chartCtx.shadowBlur = 10;

        chartCtx.beginPath();
        sp500Data.forEach((value, index) => {
            const x = paddingLeft + (chartWidth / (sp500Data.length - 1)) * index;
            const y = getLinearY(value);
            if (index === 0) {
                chartCtx.moveTo(x, y);
            } else {
                chartCtx.lineTo(x, y);
            }
        });
        chartCtx.stroke();
        chartCtx.setLineDash([]);
        chartCtx.shadowBlur = 0;

        // Draw Singularity Portfolio (gradient cyan to purple - thick line)
        drawLine(portfolioData, 'rgba(16, 185, 129, 0.95)', 4, 'rgba(16, 185, 129, 0.6)');

        // Draw labels
        chartCtx.fillStyle = 'rgba(255, 255, 255, 0.7)';
        chartCtx.font = '12px Arial';
        chartCtx.textAlign = 'center';

        // X-axis labels (months) - show every 3rd month to avoid crowding
        months.forEach((month, index) => {
            if (index % 3 === 0 || index === months.length - 1) {
                const x = paddingLeft + (chartWidth / (months.length - 1)) * index;
                chartCtx.fillText(month, x, height - paddingBottom + 25);
            }
        });

        // Y-axis labels (percentages) - linear scale matching grid lines
        chartCtx.textAlign = 'right';
        const yLabels = [120, 105, 90, 75, 60, 45, 30, 15, 0];
        yLabels.forEach((value) => {
            const y = getLinearY(value);
            chartCtx.fillText(value + '%', paddingLeft - 10, y + 5);
        });

        // Draw labels at the end of lines
        chartCtx.font = 'bold 14px Arial';
        chartCtx.textAlign = 'left';
        const endX = paddingLeft + chartWidth;

        // Singularity Portfolio label (green)
        const portfolioEndY = getLinearY(portfolioData[portfolioData.length - 1]);
        chartCtx.fillStyle = 'rgba(16, 185, 129, 1)';
        chartCtx.fillText('Singularity', endX + 10, portfolioEndY + 5);

        // S&P 500 label (gray)
        const sp500EndY = getLinearY(sp500Data[sp500Data.length - 1]);
        chartCtx.fillStyle = 'rgba(156, 163, 175, 1)';
        chartCtx.fillText('S&P 500', endX + 10, sp500EndY + 5);

    }

    // Initial draw
    resizeChart();

    // Redraw on resize
    window.addEventListener('resize', resizeChart);
}

// Count-up animation for stats
function animateCountUp() {
    const statValue = document.querySelector('.stat-value');
    if (!statValue) return;

    const targetValue = 48;
    const duration = 800; // 800ms - extremely fast
    let hasAnimated = false;
    let animationStart = null;

    function countUp(currentTime) {
        if (!animationStart) animationStart = currentTime;
        const elapsed = currentTime - animationStart;
        const progress = Math.min(elapsed / duration, 1);

        // Ease out cubic for smooth finish
        const easeOut = 1 - Math.pow(1 - progress, 3);
        const currentValue = Math.round(easeOut * targetValue);

        statValue.textContent = '+' + currentValue + '%';

        if (progress < 1) {
            requestAnimationFrame(countUp);
        }
    }

    // Intersection Observer to trigger on scroll
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !hasAnimated) {
                hasAnimated = true;
                animationStart = null;
                statValue.textContent = '+0%';
                requestAnimationFrame(countUp);
            }
        });
    }, { threshold: 0.5 });

    observer.observe(statValue);
}

// Initialize count-up animation
animateCountUp();

// Premium Card Flip & Singularity Explosion
const flipCard = document.getElementById('premium-flip-card');
const flipTrigger = document.getElementById('flip-trigger');
const flipBack = document.getElementById('flip-back');
const flipSignupForm = document.getElementById('flip-signup-form');
const explosionCanvas = document.getElementById('singularity-explosion');

if (flipCard && flipTrigger && explosionCanvas) {
    const expCtx = explosionCanvas.getContext('2d');
    let particles = [];
    let explosionActive = false;

    // Resize explosion canvas
    function resizeExplosionCanvas() {
        explosionCanvas.width = flipCard.offsetWidth;
        explosionCanvas.height = flipCard.offsetHeight;
    }
    resizeExplosionCanvas();
    window.addEventListener('resize', resizeExplosionCanvas);

    // Flip to back
    flipTrigger.addEventListener('click', (e) => {
        e.preventDefault();
        flipCard.classList.add('flipped');
    });

    // Flip to front
    flipBack.addEventListener('click', () => {
        flipCard.classList.remove('flipped');
    });

    // Particle class for singularity explosion
    class ExplosionParticle {
        constructor(x, y) {
            this.x = x;
            this.y = y;
            this.originX = x;
            this.originY = y;

            // Random angle for explosion direction
            const angle = Math.random() * Math.PI * 2;
            const speed = Math.random() * 8 + 3;
            this.vx = Math.cos(angle) * speed;
            this.vy = Math.sin(angle) * speed;

            this.size = Math.random() * 4 + 1;
            this.life = 1;
            this.decay = Math.random() * 0.015 + 0.008;

            // Light blue color palette
            const colors = [
                { r: 0, g: 212, b: 255 },     // Cyan
                { r: 135, g: 206, b: 250 },   // Light Sky Blue
                { r: 173, g: 216, b: 230 },   // Light Blue
                { r: 100, g: 200, b: 255 },   // Bright Light Blue
                { r: 200, g: 230, b: 255 },   // Pale Blue
                { r: 124, g: 58, b: 237 },    // Purple accent
                { r: 255, g: 255, b: 255 }    // White core
            ];
            this.color = colors[Math.floor(Math.random() * colors.length)];

            // Trail
            this.trail = [];
            this.maxTrail = 5;
        }

        update() {
            // Store trail position
            this.trail.push({ x: this.x, y: this.y, life: this.life });
            if (this.trail.length > this.maxTrail) {
                this.trail.shift();
            }

            // Slow down and drift
            this.vx *= 0.98;
            this.vy *= 0.98;

            this.x += this.vx;
            this.y += this.vy;

            this.life -= this.decay;
        }

        draw(ctx) {
            // Draw trail
            this.trail.forEach((point, index) => {
                const trailAlpha = (index / this.maxTrail) * point.life * 0.5;
                const trailSize = this.size * (index / this.maxTrail);
                ctx.beginPath();
                ctx.arc(point.x, point.y, trailSize, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, ${trailAlpha})`;
                ctx.fill();
            });

            // Draw glow
            const gradient = ctx.createRadialGradient(
                this.x, this.y, 0,
                this.x, this.y, this.size * 3
            );
            gradient.addColorStop(0, `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, ${this.life})`);
            gradient.addColorStop(0.5, `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, ${this.life * 0.3})`);
            gradient.addColorStop(1, `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, 0)`);

            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size * 3, 0, Math.PI * 2);
            ctx.fillStyle = gradient;
            ctx.fill();

            // Draw core
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, ${this.life})`;
            ctx.fill();
        }
    }

    // Ring wave class
    class RingWave {
        constructor(x, y) {
            this.x = x;
            this.y = y;
            this.radius = 0;
            this.maxRadius = Math.max(explosionCanvas.width, explosionCanvas.height);
            this.life = 1;
            this.speed = 6;
        }

        update() {
            this.radius += this.speed;
            this.life = 1 - (this.radius / this.maxRadius);
        }

        draw(ctx) {
            if (this.life <= 0) return;

            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.strokeStyle = `rgba(0, 212, 255, ${this.life * 0.6})`;
            ctx.lineWidth = 3 * this.life;
            ctx.stroke();

            // Inner glow ring
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius * 0.95, 0, Math.PI * 2);
            ctx.strokeStyle = `rgba(135, 206, 250, ${this.life * 0.3})`;
            ctx.lineWidth = 8 * this.life;
            ctx.stroke();
        }
    }

    let rings = [];

    function triggerExplosion() {
        explosionActive = true;
        particles = [];
        rings = [];
        explosionCanvas.classList.add('active');

        const centerX = explosionCanvas.width / 2;
        const centerY = explosionCanvas.height / 2;

        // Create particles
        for (let i = 0; i < 150; i++) {
            particles.push(new ExplosionParticle(centerX, centerY));
        }

        // Create expanding rings
        for (let i = 0; i < 3; i++) {
            setTimeout(() => {
                rings.push(new RingWave(centerX, centerY));
            }, i * 150);
        }

        animateExplosion();
    }

    function animateExplosion() {
        if (!explosionActive) return;

        expCtx.clearRect(0, 0, explosionCanvas.width, explosionCanvas.height);

        // Update and draw rings
        rings = rings.filter(ring => ring.life > 0);
        rings.forEach(ring => {
            ring.update();
            ring.draw(expCtx);
        });

        // Update and draw particles
        particles = particles.filter(p => p.life > 0);
        particles.forEach(particle => {
            particle.update();
            particle.draw(expCtx);
        });

        // Continue animation or end
        if (particles.length > 0 || rings.length > 0) {
            requestAnimationFrame(animateExplosion);
        } else {
            explosionActive = false;
            explosionCanvas.classList.remove('active');
        }
    }

    // Handle flip form submission
    flipSignupForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const submitBtn = flipSignupForm.querySelector('.flip-submit-btn');
        const originalText = submitBtn.textContent;

        // Trigger explosion
        triggerExplosion();

        // Show success state
        submitBtn.textContent = 'Welcome!';
        submitBtn.style.background = 'linear-gradient(135deg, #10b981, #059669)';

        setTimeout(() => {
            flipCard.classList.remove('flipped');
            flipSignupForm.reset();
            submitBtn.textContent = originalText;
            submitBtn.style.background = '';
        }, 2500);
    });
}

// Email Signup Popup
const signupBtn = document.getElementById('signup-btn');
const signupPopup = document.getElementById('signup-popup');
const popupClose = document.getElementById('popup-close');
const signupForm = document.getElementById('signup-form');

if (signupBtn && signupPopup) {
    // Open popup
    signupBtn.addEventListener('click', (e) => {
        e.preventDefault();
        signupPopup.classList.add('active');
        document.body.style.overflow = 'hidden';
    });

    // Close popup with X button
    popupClose.addEventListener('click', () => {
        signupPopup.classList.remove('active');
        document.body.style.overflow = '';
    });

    // Close popup when clicking overlay
    signupPopup.addEventListener('click', (e) => {
        if (e.target === signupPopup) {
            signupPopup.classList.remove('active');
            document.body.style.overflow = '';
        }
    });

    // Close popup with Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && signupPopup.classList.contains('active')) {
            signupPopup.classList.remove('active');
            document.body.style.overflow = '';
        }
    });

    // Handle form submission
    signupForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('signup-email').value;
        const submitBtn = signupForm.querySelector('.popup-submit');
        const originalText = submitBtn.textContent;

        // Show success state
        submitBtn.textContent = 'Subscribed!';
        submitBtn.style.background = 'linear-gradient(135deg, #10b981, #059669)';

        setTimeout(() => {
            signupPopup.classList.remove('active');
            document.body.style.overflow = '';
            signupForm.reset();
            submitBtn.textContent = originalText;
            submitBtn.style.background = '';
        }, 2000);
    });
}
